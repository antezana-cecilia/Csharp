﻿// See https://aka.ms/new-console-template for more information

int[] nums = new int[]{1,2,3,45,6,78,9};

foreach(int i in nums){
    Console.WriteLine("El valor es {0}",i);
}