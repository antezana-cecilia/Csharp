﻿// See https://aka.ms/new-console-template for more information
int a;

Console.WriteLine("Por favor ingrese un numero");
a = Convert.ToInt32(Console.ReadLine());


switch(a){

    case 1:
    Console.WriteLine("Es menor a 5");
    break;
    case 2:
    Console.WriteLine("Es menor a 5");
    break;
    case 5 and <=10:
    Console.WriteLine("Es mayor a 5");
    break;
    case >10 and <=100:
    Console.WriteLine("Es mayor a 5");
    break;

    default:
    Console.WriteLine("Es mayor a 100");
    break;
}