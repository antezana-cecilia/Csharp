﻿// See https://aka.ms/new-console-template for more information
int var  =15;

for(int i =0; i<=var; i++){
    Console.WriteLine("The value is {0}", i);
}
